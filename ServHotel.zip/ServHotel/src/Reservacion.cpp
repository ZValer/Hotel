#include "Reservacion.h"

#include <iostream>
using namespace std;
#include "Reservacion.h"
#include <string>

//Agrega Reservacion

Reservacion::Reservacion(){
    numeroPersonas=4;
    duracionEstancia=3;
    tipoCuarto="Suite";
    metodoPago="Tarjeta";
}

//setters
//agregar datos a cada atributo de persona

void Reservacion::setNumeroPersonas(int _numeroPersonas){
    numeroPersonas=_numeroPersonas;
}
void Reservacion::setDuracionEstancia(int _duracionEstancia){
    duracionEstancia=_duracionEstancia;
}
void Reservacion::setTipoCuarto(string _tipoCuarto){
    tipoCuarto=_tipoCuarto;
}
void Reservacion::setMetodoPago(string _metodoPago){
    metodoPago=_metodoPago;
}

//getters
int Reservacion::getNumeroPersonas(){
    return numeroPersonas;
}
int Reservacion::getDuracionEstancia(){
    return duracionEstancia;
}
string Reservacion::getTipoCuarto(){
    return tipoCuarto;
}
string Reservacion::getMetodoPago(){
    return metodoPago;
}


//m�todo que imprime datos de la reservaci�n

void Reservacion::imprimeDatosReserva(){
    cout<<"Numero de personas: "<<numeroPersonas<<endl;
    cout<<"Duracion de la estancia: "<<duracionEstancia<<endl;
    cout<<"Tipo de cuarto: "<<tipoCuarto<<endl;
    cout<<"Metodo de pago: "<<metodoPago<<endl;
}
