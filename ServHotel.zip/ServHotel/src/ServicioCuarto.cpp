#include "ServicioCuarto.h"


#include <iostream>
using namespace std;
#include <string>


ServicioCuarto::ServicioCuarto(){
    pedido=2;
}

void ServicioCuarto::imprimeDatosSC(int pqtSelec){
    if (pqtSelec==1){
        cout<<"Desayuno";
    }

    if (pqtSelec==2){
        cout<<"Comida";
    }

    if (pqtSelec==3){
        cout<<"Cena";
    }
}

void ServicioCuarto::setPedido(int numero){
    pedido=numero;
}

int ServicioCuarto::getPedido(){
    return pedido;
}

