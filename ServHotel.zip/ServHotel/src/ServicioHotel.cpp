#include "ServicioHotel.h"

#include <iostream>
using namespace std;

void ServicioHotel::solicitarServicio(){
    cout<<"Solicitar servicio...";
}

void ServicioHotel::setPrecio(int _precio){
    precio=_precio;
}

int ServicioHotel::getPrecio(){
    return precio;
}
