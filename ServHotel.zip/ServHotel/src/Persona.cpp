#include "Persona.h"


#include <iostream>
using namespace std;

#include "Persona.h"

//Agrega personas
Persona::Persona(){
    nombre="Cliente";
    telefono=911;
    correo="cliente@gmail";
}


//setters
//agregar datos a cada atributo de persona

void Persona::setNombre(string nom){
    nombre=nom;
}
void Persona::setTelefono(int tel){
    telefono=tel;
}
void Persona::setCorreo(string mail){
    correo=mail;
}
//void Persona::setReservacionPersona(){
  //  reservacionPersona.Reservacion();
//}

//getters
//regresa los datos de cada atributo de persona

string Persona::getNombre(){
    return nombre;
}
int Persona::getTelefono(){
    return telefono;
}
string Persona::getCorreo(){
    return correo;
}
//Reservacion Persona::getReservacionPersona(){
  //  return reservacionPersona.Reserva();
//}

//m�todo que imprimeDatos
string Persona::imprimeDatos(Persona cliente){
    string datos="Nombre del cliente: "+cliente.getNombre()+"  Telefono: "+"  Correo: "+cliente.getCorreo();
    return datos;
}

