#include "ServicioEspecial.h"

#include <iostream>
using namespace std;
#include <string>

ServicioEspecial::ServicioEspecial(){
    pqtSeleccionado=2;
}

void ServicioEspecial::imprimeDatosPqt(int pqtSeleccionado){
    if (pqtSeleccionado==1){
        cout<<"Luna de miel";
    }

    if (pqtSeleccionado==2){
        cout<<"Familiar";
    }

    if (pqtSeleccionado==3){
        cout<<"VIP";
    }
}

void ServicioEspecial::setPqtSeleccionado(int num){
    pqtSeleccionado=num;
}

int ServicioEspecial::getPqtSeleccionado(){
    return pqtSeleccionado;
}

