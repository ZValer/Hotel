#ifndef SERVICIOCUARTO_H
#define SERVICIOCUARTO_H

#include <iostream>
using namespace std;

#include <string>

class ServicioCuarto
{
    private: //atributo
        int pedido;

    public: //m�todos
        ServicioCuarto();
        void imprimeDatosSC(int);
        void setPedido(int);
        int getPedido();
};

#endif // SERVICIOCUARTO_H
