#ifndef PERSONA_H
#define PERSONA_H

#include <iostream>
using namespace std;

#include <string>
#include "Reservacion.h"

class Persona
{
    private: //atributos
        string nombre;
        int telefono;
        string correo;
        //Reservacion reservacionPersona; //Relaci�n de tipo composici�n
                                    //Una persona puede tener una reservaci�n
                                    //La reservaci�n no puede existir sin la persona

    public: //m�todos
        Persona();
        string imprimeDatos(Persona);

        //getters y setters de cada atributo
        void setNombre(string);
        string getNombre();
        void setTelefono(int);
        int getTelefono();
        void setCorreo(string);
        string getCorreo();

        //void setreservacionPersona();
        //string getreservacionPersona();
};



#endif // PERSONA_H
