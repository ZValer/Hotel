#ifndef MAIN_CPP
#define MAIN_CPP


#include <iostream>
#include "Persona.h"
#include "ServicioEspecial.h"
#include "ServicioCuarto.h"

using namespace std;
#include <string>

int main ()
{
    Persona cliente;
    //Imprime datos del cliente
    cout<<"Datos del cliente "<<endl;
    cout<<cliente.imprimeDatos(cliente)<<endl;

    Reservacion _reserva;

    //Imprime datos de la reservaci�n
    cout<<"\nDatos de la reservacion"<<endl;

    _reserva.imprimeDatosReserva();

    //Imprime lista de paquetes del Servicio Especial
    cout <<"\nLista de paquetes de servicio especial"<<endl;
    cout<<"1.Luna de miel \n2.Familiar \n3.VIP "<<endl;

    //crea un objeto de Servicio Especial
    ServicioEspecial _paqueteEspecial;

    int paq;
    cout<<"Selecciona un paquete (1/2/3): "<<endl;
    cin>>paq;
    _paqueteEspecial.imprimeDatosPqt(paq);

    //scntjgnbtg

    //Imprime lista de paquetes del Servicio al cuarto
    cout <<"\nLista de paquetes de servicio al cuarto"<<endl;
    cout<<"1.Desayuno \n2.Comida \n3.Cena "<<endl;

    //crea un objeto de Servicio al cuarto
    ServicioCuarto _paqueteServicioCuarto;

    int paqServicioCuarto;
    cout<<"Selecciona un paquete (1/2/3): "<<endl;
    cin>>paqServicioCuarto;
    _paqueteServicioCuarto.imprimeDatosSC(paqServicioCuarto);


    return 0;
}


#endif // MAIN_CPP
