#ifndef SERVICIOESPECIAL_H
#define SERVICIOESPECIAL_H

#include <iostream>
using namespace std;

#include <string>

class ServicioEspecial
{
    private: //atributo
        int pqtSeleccionado;

    public: //m�todos
        ServicioEspecial();
        void imprimeDatosPqt(int);
        void setPqtSeleccionado(int);
        int getPqtSeleccionado();
};

#endif // SERVICIOESPECIAL_H
