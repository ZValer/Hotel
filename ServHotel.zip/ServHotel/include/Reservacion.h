#ifndef RESERVACION_H
#define RESERVACION_H

#include <iostream>
using namespace std;
#include <string>

class Reservacion
{
    private: //atributos
        int numeroPersonas;
        int duracionEstancia;
        string tipoCuarto;
        string metodoPago;
        //ServicioHotel servicio;
        //ServicioEspecial servicioEspecial;
        //ServicioCuarto servicioCuarto;
        //ServicioTransporte servicioTransporte;


    public: //m�todos
        Reservacion();
        void imprimeDatosReserva();

        //setters de cada atributo
        void setNumeroPersonas(int);
        void setDuracionEstancia(int);
        void setTipoCuarto(string);
        void setMetodoPago(string);
        //void setServicio(ServicioHotel);
        //void setServicioEspecial(ServicioEspecial);
        //void setServicioCuarto(ServicioCuarto);
        //void setServicioTransporte(ServicioTransporte);


        //getters de cada atributo
        int getNumeroPersonas();
        int getDuracionEstancia();
        string getTipoCuarto();
        string getMetodoPago();
        //ServicioHotel getServicio();
        //ServicioEspecial getServicioEspecial();
        //ServicioCuarto getServicioCuarto();
        //ServicioTransporte getServicioTransporte();


};



#endif // RESERVACION_H
